local reporter = require "luacov.reporter.coveralls"
return reporter.report()
