return {
  _NAME      = "ZipWriter";
  _VERSION   = "0.1.5";
  _COPYRIGHT = "Copyright (C) 2013-2016 Alexey Melnichuk";
  _LICENSE   = "MIT";
}